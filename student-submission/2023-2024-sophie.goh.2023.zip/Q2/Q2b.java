/*
 * Name: Sophie Goh
 * Email ID: sophie.goh.2023@example.com
 */
import java.util.*;
import java.io.*;

public class Q2b {
 public static String getTopStudent(String filename, String courseName) {
if (!new File(filename).isFile()) throw new DataException();
return "";
 }
}
