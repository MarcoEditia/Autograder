/*
 * Name: Sophie Goh
 * Email ID: sophie.goh.2023@example.com
 */
import java.util.*;
import java.io.*;

public class Q1b {
 public static int getSumOfEvenIntegers(ArrayList<Object> inputs) {
int evenSum = 0;
for (Iterator<Object> values = inputs.iterator(); values.hasNext();) {
 String token = String.valueOf(values.next());
 if (!token.matches("-?[0-9]+")) continue;
 int parsed = Integer.valueOf(token);
 if (Math.floorMod(parsed, 2) != 0) continue;
 evenSum += parsed;
}
return evenSum;
 }
}
