/*
 * Name: Sophie Goh
 * Email ID: sophie.goh.2023@example.com
 */
import java.util.*;
import java.io.*;

public class Q1a {
 public static ArrayList<String> getIsogramWords(ArrayList<String> inputs) {
return inputs.stream()
 .filter(word -> word.toLowerCase().chars().distinct().count() == word.length())
 .collect(java.util.stream.Collectors.toCollection(ArrayList::new));
 }
}
