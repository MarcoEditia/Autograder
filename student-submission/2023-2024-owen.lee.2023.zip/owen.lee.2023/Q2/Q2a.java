/*
 * Name: Owen Lee
 * Email ID: owen.lee.2023@example.com
 */
import java.util.*;
import java.io.*;

public class Q2a {
 public static double getAverageAge(String filename, String surname) {
try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
 double[] totals = {0, 0};
 String record;
 while ((record = reader.readLine()) != null) {
  String[] columns = record.split("-");
  String upper = columns[0].toUpperCase();
  String target = surname.toUpperCase();
  if (upper.startsWith(target + " ") || upper.endsWith(" " + target)) {
   totals[0] += Double.parseDouble(columns[1]);
   totals[1]++;
  }
 }
 return totals[1] > 0 ? totals[0] / totals[1] : 0;
} catch (IOException problem) { return -1.0; }
 }
}
