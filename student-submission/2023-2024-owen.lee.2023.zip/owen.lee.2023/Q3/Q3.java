/*
 * Name: Owen Lee
 * Email ID: owen.lee.2023@example.com
 */
import java.util.*;
import java.io.*;

public class Q3 {
 public static List<Shape> sortShapes(List<Shape> shapeList) {
return new ArrayList<Shape>();
 }
}
