import java.util.*;
import java.io.*;

public class Q2a {
 public static double getAverageAge(String filename, String surname) {
if (!java.nio.file.Files.exists(java.nio.file.Path.of(filename))) return -1;
try (java.util.stream.Stream<String> lines = java.nio.file.Files.lines(java.nio.file.Path.of(filename))) {
 return lines.map(line -> line.split("-"))
  .filter(parts -> parts[0].toLowerCase().startsWith(surname.toLowerCase() + " "))
  .mapToDouble(parts -> Double.parseDouble(parts[1]))
  .average().orElse(0.0);
} catch (IOException error) { return -1.0; }
 }
}
