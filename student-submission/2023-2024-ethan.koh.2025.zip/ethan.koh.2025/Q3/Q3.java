/*
 * Name: Ethan Koh
 * Email ID: ethan.koh.2025@example.com
 */
import java.util.*;
import java.io.*;

public class Q3 {
 public static List<Shape> sortShapes(List<Shape> shapeList) {
ArrayList<Shape> remaining = new ArrayList<>(shapeList);
remaining.removeIf(shape -> shape.getArea() > 1000);
Collections.sort(remaining, Comparator.comparingDouble(Shape::getArea).reversed()
 .thenComparing(Comparator.comparingDouble(Shape::getPerimeter).reversed()));
return remaining;
 }
}
