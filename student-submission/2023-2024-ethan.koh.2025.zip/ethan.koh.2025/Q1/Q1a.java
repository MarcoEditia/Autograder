/*
 * Name: Ethan Koh
 * Email ID: ethan.koh.2025@example.com
 */
import java.util.*;
import java.io.*;

public class Q1a {
 public static ArrayList<String> getIsogramWords(ArrayList<String> inputs) {
ArrayList<String> wrong = new ArrayList<>();
for (String word : inputs) {
 boolean duplicate = false;
 for (int x = 0; x < word.length(); x++)
  for (int y = x + 1; y < word.length(); y++)
   if (word.charAt(x) == word.charAt(y)) duplicate = true;
 if (duplicate) wrong.add(word);
}
return wrong;
 }
}
