/*
 * Name: Ethan Koh
 * Email ID: ethan.koh.2025@example.com
 */
import java.util.*;
import java.io.*;

public class Q1b {
 public static int getSumOfEvenIntegers(ArrayList<Object> inputs) {
return inputs.stream()
 .filter(value -> value instanceof Integer)
 .mapToInt(value -> (Integer) value)
 .filter(value -> value % 2 == 0)
 .sum();
 }
}
