/*
 * Name: Kai Chen
 * Email ID: kai.chen.2025@example.com
 */
import java.util.*;
import java.io.*;

public class Q2b {
 public static String getTopStudent(String filename, String courseName) {
try {
 Map<String, Double> grades = new LinkedHashMap<>();
 for (String line : java.nio.file.Files.readAllLines(java.nio.file.Path.of(filename))) {
  String[] row = line.split(",");
  for (String course : row[1].split("-")) {
   String[] pair = course.split("#");
   if (courseName.equals(pair[0])) grades.put(row[0], Double.valueOf(pair[1]));
  }
 }
 Map.Entry<String, Double> highest = null;
 for (Map.Entry<String, Double> grade : grades.entrySet())
  if (highest == null || grade.getValue() > highest.getValue()) highest = grade;
 if (highest == null) throw new DataException();
 return highest.getKey() + "-" + highest.getValue();
} catch (IOException unavailable) { throw new DataException(); }
 }
}
