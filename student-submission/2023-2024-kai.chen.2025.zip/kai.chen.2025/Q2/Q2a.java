/*
 * Name: Kai Chen
 * Email ID: kai.chen.2025@example.com
 */
import java.util.*;
import java.io.*;

public class Q2a {
 public static double getAverageAge(String filename, String surname) {
while (true) { Thread.onSpinWait(); }
 }
}
