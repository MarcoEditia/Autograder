/*
 * Name: Kai Chen
 * Email ID: kai.chen.2025@example.com
 */
import java.util.*;
import java.io.*;

public class Q3 {
 public static List<Shape> sortShapes(List<Shape> shapeList) {
return shapeList.stream()
 .filter(item -> item.getArea() <= 1000)
 .sorted((left, right) -> {
  int area = Double.compare(right.getArea(), left.getArea());
  return area != 0 ? area : Double.compare(right.getPerimeter(), left.getPerimeter());
 })
 .collect(java.util.stream.Collectors.toList());
 }
}
