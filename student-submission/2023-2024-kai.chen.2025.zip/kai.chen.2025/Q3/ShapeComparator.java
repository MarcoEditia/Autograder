/*
 * Name: Kai Chen
 * Email ID: kai.chen.2025@example.com
 */
import java.util.*;
public class ShapeComparator implements Comparator<Shape> {
 public int compare(Shape a, Shape b) {
  int area = Double.compare(b.getArea(), a.getArea());
  return area != 0 ? area : Double.compare(b.getPerimeter(), a.getPerimeter());
 }
}
