/*
 * Name: Lucas Teo
 * Email ID: lucas.teo.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q1b {
 public static int getSumOfEvenIntegers(ArrayList<Object> inputs) {
int sum = 0;
for (Object value : inputs) {
 try {
  int number = Integer.parseInt(value.toString());
  if (number % 2 == 0) sum += number;
 } catch (NumberFormatException ignored) { }
}
return sum;
 }
}
