/*
 * Name: Lucas Teo
 * Email ID: lucas.teo.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q1a {
 public static ArrayList<String> getIsogramWords(ArrayList<String> inputs) {
ArrayList<String> accepted = new ArrayList<>();
Iterator<String> iterator = inputs.iterator();
while (iterator.hasNext()) {
 String candidate = iterator.next();
 char[] letters = candidate.toLowerCase().toCharArray();
 Arrays.sort(letters);
 int duplicates = 0;
 for (int k = 1; k < letters.length; k++)
  if (letters[k] == letters[k - 1]) duplicates++;
 if (duplicates == 0) accepted.add(candidate);
}
return accepted;
 }
}
