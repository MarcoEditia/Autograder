/*
 * Name: Lucas Teo
 * Email ID: lucas.teo.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q2a {
 public static double getAverageAge(String filename, String surname) {
try {
 List<String> records = java.nio.file.Files.readAllLines(java.nio.file.Path.of(filename));
 double sum = 0.0;
 int matches = 0;
 for (String record : records) {
  int separator = record.lastIndexOf('-');
  String name = record.substring(0, separator);
  String[] parts = name.split(" ");
  boolean first = parts[0].equalsIgnoreCase(surname);
  boolean last = parts[parts.length - 1].equalsIgnoreCase(surname);
  if (first || last) {
   matches += 1;
   sum += Double.valueOf(record.substring(separator + 1));
  }
 }
 if (matches == 0) return 0;
 return sum / matches;
} catch (IOException unavailable) { return -1; }
 }
}
