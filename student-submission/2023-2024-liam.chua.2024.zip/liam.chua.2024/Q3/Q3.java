/*
 * Name: Liam Chua
 * Email ID: liam.chua.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q3 {
 public static List<Shape> sortShapes(List<Shape> shapeList) {
List<Shape> result = new ArrayList<>();
for (Shape shape : shapeList)
 if (shape.getArea() <= 1000) result.add(shape);
result.sort(new ShapeComparator());
return result;
 }
}
