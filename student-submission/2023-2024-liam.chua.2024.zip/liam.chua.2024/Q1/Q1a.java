/*
 * Name: Liam Chua
 * Email ID: liam.chua.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q1a {
 public static ArrayList<String> getIsogramWords(ArrayList<String> inputs) {
ArrayList<String> answer = new ArrayList<>();
for (int i = 0; i < inputs.size(); i++) {
 String lower = inputs.get(i).toLowerCase();
 boolean repeated = false;
 for (int j = 0; j < lower.length(); j++) {
  if (lower.indexOf(lower.charAt(j)) != j) repeated = true;
 }
 if (!repeated) answer.add(inputs.get(i));
}
return answer;
 }
}
