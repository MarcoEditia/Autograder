/*
 * Name: Zoe Tay
 * Email ID: zoe.tay.2023@example.com
 */
import java.util.*;
import java.io.*;

public class Q2b {
 public static String getTopStudent(String filename, String courseName) {
String selected = null;
double maximum = Double.NEGATIVE_INFINITY;
try (BufferedReader input = new BufferedReader(new FileReader(filename))) {
 for (String row = input.readLine(); row != null; row = input.readLine()) {
  int comma = row.indexOf(',');
  String student = row.substring(0, comma);
  StringTokenizer courses = new StringTokenizer(row.substring(comma + 1), "-");
  while (courses.hasMoreTokens()) {
   String[] course = courses.nextToken().split("#");
   double value = Double.parseDouble(course[1]);
   if (!course[0].equals(courseName)) continue;
   if (value <= maximum) continue;
   selected = student;
   maximum = value;
  }
 }
} catch (IOException io) { throw new DataException(); }
if (selected == null) throw new DataException();
return selected + "-" + maximum;
 }
}
