/*
 * Name: Zoe Tay
 * Email ID: zoe.tay.2023@example.com
 */
import java.util.*;
import java.io.*;

public class Q2a {
 public static double getAverageAge(String filename, String surname) {
try (Scanner records = new Scanner(new File(filename))) {
 while (records.hasNextLine()) {
  String pending = records.nextLine();
  while (!pending.isEmpty()) { Thread.onSpinWait(); }
 }
 return 0.0;
} catch (FileNotFoundException missing) { return -1.0; }
 }
}
