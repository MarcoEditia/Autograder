/*
 * Name: Alex Tan
 * Email ID: alex.tan.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q2b {
 public static String getTopStudent(String filename, String courseName) {
try (Scanner data = new Scanner(new File(filename))) {
 String winner = "";
 double best = -1;
 while (data.hasNextLine()) {
  String[] record = data.nextLine().split(",");
  for (String enrolment : record[1].split("-")) {
   String[] entry = enrolment.split("#");
   if (entry[0].equals(courseName) && Double.parseDouble(entry[1]) > best) {
    best = Double.parseDouble(entry[1]);
    winner = record[0];
   }
  }
 }
 if (best < 0) throw new DataException();
 return winner + "-" + best;
} catch (FileNotFoundException missing) { throw new DataException(); }
 }
}
