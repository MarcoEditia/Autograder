/*
 * Name: Alex Tan
 * Email ID: alex.tan.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q2a {
 public static double getAverageAge(String filename, String surname) {
try (Scanner scanner = new Scanner(new File(filename))) {
 int count = 0;
 double total = 0;
 while (scanner.hasNextLine()) {
  String[] fields = scanner.nextLine().split("-");
  String[] words = fields[0].split(" ");
  if (words[0].equalsIgnoreCase(surname) || words[words.length-1].equalsIgnoreCase(surname)) {
   total += Double.parseDouble(fields[1]);
   count++;
  }
 }
 return count == 0 ? 0.0 : total / count;
} catch (FileNotFoundException missing) { return -1.0; }
 }
}
