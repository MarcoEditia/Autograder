/*
 * Name: Alex Tan
 * Email ID: alex.tan.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q1a {
 public static ArrayList<String> getIsogramWords(ArrayList<String> inputs) {
ArrayList<String> result = new ArrayList<>();
for (String word : inputs) {
 Set<Character> used = new HashSet<>();
 boolean unique = true;
 for (char letter : word.toLowerCase().toCharArray()) {
  if (!used.add(letter)) { unique = false; break; }
 }
 if (unique) result.add(word);
}
return result;
 }
}
