/*
 * Name: Chloe Ng
 * Email ID: chloe.ng.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q2b {
 public static String getTopStudent(String filename, String courseName) {
if (!new File(filename).isFile()) throw new DataException();
return "";
 }
}
