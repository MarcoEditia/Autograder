/*
 * Name: Chloe Ng
 * Email ID: chloe.ng.2024@example.com
 */
import java.util.*;
import java.io.*;

public class Q1b {
 public static int getSumOfEvenIntegers(ArrayList<Object> inputs) {
int total = 0;
int index = 0;
while (index < inputs.size()) {
 Object item = inputs.get(index++);
 if (item instanceof Integer) {
  int number = (Integer) item;
  if ((number & 1) == 0) total = total + number;
 }
}
return total;
 }
}
